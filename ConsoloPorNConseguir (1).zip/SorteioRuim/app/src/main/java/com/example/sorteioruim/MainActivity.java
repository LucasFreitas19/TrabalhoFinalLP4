package com.example.sorteioruim;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    List<String> nomes = new ArrayList();


    public void sortear(View view){

        TextView resutlado = findViewById(R.id.resultado);

        String result = sorteio();

        resutlado.setText("Sorteado: " + result);

    }

    public void lista(View view){

        TextView nome = findViewById(R.id.textView);
        String y = nome.getText().toString();

        nomes.add(y);

    }

    public String sorteio(){

        int x = new Random().nextInt(nomes.size());
       String resultado =  nomes.get(x);

       return resultado;
    }
}