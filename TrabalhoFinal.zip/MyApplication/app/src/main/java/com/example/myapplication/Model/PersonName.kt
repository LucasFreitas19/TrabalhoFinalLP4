package com.example.myapplication.Model

data class PersonName(val name: String)
