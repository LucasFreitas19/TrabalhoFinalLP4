package com.example.myapplication.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProvider
import com.example.myapplication.R
import com.example.myapplication.ViewModel.SorteioName
import com.example.myapplication.ViewModel.SorteioNameFactory
import com.example.myapplication.databinding.ActivitySorteioBinding

class Sorteio : AppCompatActivity() {

    private val sorteioViewModel: SorteioName by lazy {
        ViewModelProvider(this, SorteioNameFactory)[SorteioName::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
     //   setContentView(R.layout.activity_sorteio)

        val nameBinding: ActivitySorteioBinding =  DataBindingUtil.setContentView(this, R.layout.activity_sorteio)
        nameBinding.viewmodel = sorteioViewModel
    }
}