package com.example.myapplication.Infra

import com.example.myapplication.Model.Nome
import com.example.myapplication.Model.PersonName
import okhttp3.Request
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface SorteioService {

    @POST("/v1/secret-friend/keeper")
    suspend fun postnome(@Body personName: PersonName): Response<Nome>

   // @GET("/v1/secret-friend/keeper")
    //suspend fun getSorteio(@ nome: String): Request<String>
}