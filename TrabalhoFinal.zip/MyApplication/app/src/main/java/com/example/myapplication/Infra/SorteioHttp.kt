package com.example.myapplication.Infra

import com.example.myapplication.Model.Nome
import com.example.myapplication.Model.PersonName
import com.google.gson.Gson
import com.google.gson.internal.bind.TypeAdapters.URL
import java.io.InputStreamReader
import java.io.Reader
import java.net.HttpURLConnection
import java.net.URL

object SorteioHttp {

    private const val sorteioUrl = "http://business-controll-backend.herokuapp.com/v1/secret-friend/keeper"

    private val gson: Gson = Gson()

    suspend fun doInput(personName: PersonName): Result<Nome>{
        val url = URL(sorteioUrl)

        (url.openConnection() as HttpURLConnection).run {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; utf-8")
            setRequestProperty("Accept", "application/json")

            doOutput = true
            outputStream.write(gson.toJson(personName).toByteArray())

            val reader: Reader = InputStreamReader(inputStream, "utf-8")

            val participanteNome = gson.fromJson(reader, Nome::class.java)

            return Result.success(participanteNome)
        }

    }
}