package com.example.myapplication.Model

data class Nome(val name: String)
