package com.example.myapplication.Repository

import com.example.myapplication.Infra.SorteioAPI
import com.example.myapplication.Infra.SorteioHttp
import com.example.myapplication.Model.Nome
import com.example.myapplication.Model.PersonName

class Repository {

    val sorteioService = SorteioAPI.sorteioService

    suspend fun name_recived(nome: String): Result<Nome> {

        val response = sorteioService.postnome(PersonName(nome))

        return Result.success(response.body()!!)
    }


}