package com.example.myapplication.Infra

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object SorteioAPI {

    private const val API_BASE = "http://business-controll-backend.herokuapp.com"

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(API_BASE)
            .addConverterFactory(GsonConverterFactory
                .create())
            .build()
    }

    val sorteioService: SorteioService by lazy {
        retrofit.create(SorteioService::class.java)
    }
}